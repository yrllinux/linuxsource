
class Dot : public CEdit
{
public:
	//Dot(CWnd* pParent = NULL);	// standard constructor

	afx_msg void OnChar(unsigned int nChar, unsigned int nRepCnt, unsigned int nFlags);
};

