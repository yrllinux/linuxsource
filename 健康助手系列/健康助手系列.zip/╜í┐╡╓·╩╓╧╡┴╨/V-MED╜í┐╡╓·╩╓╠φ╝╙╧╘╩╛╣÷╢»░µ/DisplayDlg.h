#if !defined(AFX_DISPLAYDLG_H__9967F10D_C697_42C0_B5D9_A737579C5ACB__INCLUDED_)
#define AFX_DISPLAYDLG_H__9967F10D_C697_42C0_B5D9_A737579C5ACB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DisplayDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDisplayDlg dialog

class CDisplayDlg : public CDialog
{
// Construction
public:
	CDisplayDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDisplayDlg)
	enum { IDD = IDD_DIALOG2 };
	CListBox	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDisplayDlg)
	afx_msg void OnSelchangeList1();
	virtual void OnOK();
	afx_msg void OnChangeEdit2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
extern CDisplayDlg *pDlg;

#endif // !defined(AFX_DISPLAYDLG_H__9967F10D_C697_42C0_B5D9_A737579C5ACB__INCLUDED_)
