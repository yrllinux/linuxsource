#if !defined(AFX_TEST2DLG_H__CCFF429A_BCD5_423E_82D4_09337DE7B21F__INCLUDED_)
#define AFX_TEST2DLG_H__CCFF429A_BCD5_423E_82D4_09337DE7B21F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Test2Dlg.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CTest2Dlg dialog

class CTest2Dlg : public CDialog
{
// Construction
public:
	CTest2Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTest2Dlg)
	enum { IDD = IDD_DIALOG1 };
	CStatic	m_static12;
	CStatic	m_static11;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest2Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CTest2Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnStatic16();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST2DLG_H__CCFF429A_BCD5_423E_82D4_09337DE7B21F__INCLUDED_)
