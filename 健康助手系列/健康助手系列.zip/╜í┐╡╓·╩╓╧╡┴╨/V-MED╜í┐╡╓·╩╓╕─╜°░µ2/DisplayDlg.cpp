// DisplayDlg.cpp : implementation file
//

#include "stdafx.h"
#include "V_MED.h"
#include "DisplayDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CFont font24;
CFont font25;
//CBrush m_brush;   

int fenshu1 = 0;
int fenshu2 = 0;
float fenshu3 = 0;
/////////////////////////////////////////////////////////////////////////////
// CDisplayDlg dialog


CDisplayDlg::CDisplayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDisplayDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDisplayDlg)
	//}}AFX_DATA_INIT
}


void CDisplayDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDisplayDlg)
	//DDX_Control(pDX, IDC_STATIC24, RichStatic);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDisplayDlg, CDialog)
	//{{AFX_MSG_MAP(CDisplayDlg)
	ON_CONTROL(STN_CLICKED,IDC_STATIC24, OnStatic) 
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayDlg message handlers
BOOL CDisplayDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//���������С
    font24.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, TRUE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("���Ŀ���"));
	GetDlgItem(IDC_STATIC24)->SetFont(&font24);

	//���������С
    font25.CreateFont(20, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("���Ŀ���"));
	GetDlgItem(IDC_STATIC25)->SetFont(&font25);

	GetDlgItem(IDC_STATIC28)->SetFont(&font25);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

//void CDisplayDlg::OnSelchangeList1() 
//{
	// TODO: Add your control notification handler code here
//}

CDisplayDlg *pDlg = NULL;

void CDisplayDlg::OnOK() 
{
	// TODO: Add extra validation here

	CDialog::OnOK();

	font24.DeleteObject();
	font25.DeleteObject();
		
	if(pDlg)
		delete pDlg;

	pDlg = NULL;
}

void CDisplayDlg::OnChangeEdit2() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}

void CDisplayDlg::OnStatic() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	ShellExecute(0, NULL, _T("http://www.v-med.org"), NULL, NULL, SW_NORMAL);
	
	font24.DeleteObject();
	font25.DeleteObject();
		
	if(pDlg)
		delete pDlg;

	pDlg = NULL;
}

HBRUSH CDisplayDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	//�ı侲̬�ı���ɫ
	switch (pWnd->GetDlgCtrlID())
	{
	case IDC_STATIC24:
		{
			pDC->SetTextColor(RGB(0,0,255));
			//pDC->SetBkColor(RGB(251, 247, 200));
			//pDC->SetBkMode(TRANSPARENT);
			//return (HBRUSH) m_brush.GetSafeHandle();
		}
	break;

	case IDC_STATIC26:
		{
			if(fenshu1 < 80)
				pDC->SetTextColor(RGB(255,0,0));		//��ɫ
			else if(fenshu1 >= 80 && fenshu1 <= 90)
				pDC->SetTextColor(RGB(255, 165, 0));	//��ɫ
			else if(fenshu1 > 90)
				pDC->SetTextColor(RGB(0,255,0));		//��ɫ
		}
	break;
	case IDC_STATIC27:
		{
			if(fenshu2 < 80)
				pDC->SetTextColor(RGB(255,0,0));		//��ɫ
			else if(fenshu2 >= 80 && fenshu2 <= 90)
				pDC->SetTextColor(RGB(255, 165, 0));	//��ɫ
			else if(fenshu2 > 90)
				pDC->SetTextColor(RGB(0,255,0));		//��ɫ
		}
	break;
	case IDC_STATIC28:
		{
			if(fenshu3 < 80.00)
				pDC->SetTextColor(RGB(255,0,0));		//��ɫ
			else if(fenshu3 >= 80.00 && fenshu3 <= 90.00)
				pDC->SetTextColor(RGB(255, 165, 0));	//��ɫ
			else if(fenshu3 > 90.00)
				pDC->SetTextColor(RGB(0,255,0));		//��ɫ
		}
	break;
	}	

	//�ı�Edit�༭����������ɫ
	//if(nCtlColor == CTLCOLOR_EDIT)
	//{
	//	if(pWnd->GetDlgCtrlID()== IDC_EDIT1)
	//	{
	//	   pDC->SetTextColor(RGB(255,255,0));
	//	   pDC->SetBkColor(RGB(251, 247, 200));
	//	   pDC->SetBkMode(TRANSPARENT);
	//	   return (HBRUSH) m_brush.GetSafeHandle();
	//	}
	//}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

