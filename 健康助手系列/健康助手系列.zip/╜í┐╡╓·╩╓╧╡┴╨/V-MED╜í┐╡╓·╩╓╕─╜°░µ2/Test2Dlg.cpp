// Test2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "V_MED.h"
#include "Test2Dlg.h"
#include "V_MEDDlg.h"
#include "DisplayDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest2Dlg dialog
CFont font1;
CFont font2;
CFont font3;
CFont font4;
CFont font5;
CFont font6;
CFont font7;

CTest2Dlg::CTest2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTest2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTest2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTest2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTest2Dlg)
	DDX_Control(pDX, IDC_STATIC12, m_static12);
	DDX_Control(pDX, IDC_STATIC11, m_static11);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTest2Dlg, CDialog)
	//{{AFX_MSG_MAP(CTest2Dlg)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_STATIC16, OnStatic16)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest2Dlg message handlers

BOOL CTest2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//��������1
    font1.CreateFont(30, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("����"));
    m_static11.SetFont(&font1);

	//��������2
    font2.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("����"));
	m_static12.SetFont(&font2); 

	//��������3
    font3.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("����"));
	GetDlgItem(IDC_STATIC13)->SetFont(&font3); 

	//��������4
    font4.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("����"));
	GetDlgItem(IDC_STATIC14)->SetFont(&font4);

	//��������5
    font5.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("����"));
	GetDlgItem(IDC_STATIC15)->SetFont(&font5);
	
	//��������6
    font6.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, TRUE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("���Ŀ���"));
	GetDlgItem(IDC_STATIC16)->SetFont(&font6);

	//��������7
    font7.CreateFont(16, 0, 0, 0, FW_BLACK, FALSE, FALSE, 0, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
		DEFAULT_PITCH | FF_SWISS, _T("���Ŀ���"));
	GetDlgItem(IDC_STATIC17)->SetFont(&font7);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTest2Dlg::OnOK() 
{
	// TODO: Add extra validation here
	this->ShowWindow(SW_HIDE);  

	CV_MEDDlg MEDDlg;
	MEDDlg.DoModal();

	CDialog::OnOK();

	font1.DeleteObject();
	font2.DeleteObject();
	font3.DeleteObject();
	font4.DeleteObject();
	font5.DeleteObject();
	font6.DeleteObject();
	font7.DeleteObject();
}

void CTest2Dlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

CBrush m_brush;

HBRUSH CTest2Dlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	//m_brush.CreateHatchBrush(HS_CROSS,RGB(255,255,0));

	//�ı侲̬�ı���ɫ
	switch (pWnd->GetDlgCtrlID())
	{
	case IDC_STATIC16:
		{
			pDC->SetTextColor(RGB(0,0,255));
			//pDC->SetBkColor(RGB(0, 255, 0));
			//pDC->SetBkMode(TRANSPARENT);
			//return (HBRUSH) m_brush.GetSafeHandle();
		}
	break;

	default :
		//pDC->SetBkColor(RGB(0, 255, 0));
		//pDC->SetBkMode(TRANSPARENT);
		//return (HBRUSH) m_brush.GetSafeHandle();
		break;
	}
	
	// TODO: Change any attributes of the DC here
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CTest2Dlg::OnStatic16() 
{
	// TODO: Add your control notification handler code here
	ShellExecute(0, NULL, _T("http://www.v-med.org"), NULL, NULL, SW_NORMAL);
}
