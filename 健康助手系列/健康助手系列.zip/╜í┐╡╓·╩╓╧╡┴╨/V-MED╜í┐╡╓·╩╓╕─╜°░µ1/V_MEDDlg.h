// V_MEDDlg.h : header file
//

#if !defined(AFX_V_MEDDLG_H__0559C8F0_BFBA_468A_A6D6_4841AF842C50__INCLUDED_)
#define AFX_V_MEDDLG_H__0559C8F0_BFBA_468A_A6D6_4841AF842C50__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CV_MEDDlg dialog

class CV_MEDDlg : public CDialog
{
// Construction
public:
	CV_MEDDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CV_MEDDlg)
	enum { IDD = IDD_V_MED_DIALOG };
	CComboBox	m_cb5;
	CComboBox	m_cb4;
	CComboBox	m_cb3;
	CComboBox	m_cb2;
	CComboBox	m_cb1;
	CStatic	m_static22;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CV_MEDDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CV_MEDDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnXingMing();
	afx_msg void OnNianLing();
	afx_msg void OnTiZhong();
	afx_msg void OnCD4();
	afx_msg void OnVL();
	afx_msg void OnWBC();
	afx_msg void OnPLT();
	afx_msg void OnHGB();
	afx_msg void OnALT();
	afx_msg void OnAST();
	afx_msg void OnGGT();
	afx_msg void OnALP();
	afx_msg void OnTBIL();
	afx_msg void OnCr();
	afx_msg void OnGLU();
	afx_msg void OnTG();
	afx_msg void OnCHOL();
	afx_msg void OnULEU();
	afx_msg void OnBLO();
	afx_msg void OnPRO();
	afx_msg void OnGLU2();
	afx_msg void OnURO();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnEditchangeCombo1();
	afx_msg void OnEditchangeCombo2();
	afx_msg void OnEditchangeCombo3();
	afx_msg void OnEditchangeCombo4();
	afx_msg void OnEditchangeCombo5();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_V_MEDDLG_H__0559C8F0_BFBA_468A_A6D6_4841AF842C50__INCLUDED_)
