
#include "hash_list.h"

#ifndef __QUEUE_H__
#define __QUEUE_H__

#ifdef __cplusplus
	extern "C" {
#endif

#pragma pack(1)
typedef struct
{
	ListNode_t *front; /* ��ͷָ�� */
	ListNode_t *rear;  /* ��βָ�� */
}LinkQueue;
#pragma pack()

extern LinkQueue pool; 		//�ض���

int init_mempool_Queue(LinkQueue *Q);
int InitQueue(LinkQueue *Q);
int DestroyQueue(LinkQueue *Q);
int EnQueue(LinkQueue *Q, ListNode_t *p);
int DeQueue(LinkQueue *Q, ListNode_t **p_out);

#ifdef __cplusplus
}
#endif

#endif

