#include "queue.h"

int main(int argc, char *argv[])
{
	memset(g_MapTable, 0, sizeof(g_MapTable));

	int ret = InitQueue(&pool);
	ret |= init_mempool_Queue(&pool);
	if(ret == -1)
	{
		printf("init Queue fail");
		return -1;
	}

	HashTable_t* pHashTbl = create_hash_table();
#if 0
	insert_data_into_hash(pHashTbl,hash("192.168.0.64", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.65", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.66", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.67", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.68", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.69", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.60", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.61", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.62", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.63", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.75", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.86", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.94", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.15", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.26", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.34", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.45", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.0.56", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.1.64", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.2.65", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.3.66", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.4.64", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.5.65", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.6.66", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.7.64", sizeof("192.168.0.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.8.65", sizeof("192.168.0.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.9.66", sizeof("192.168.0.66")));
	insert_data_into_hash(pHashTbl,hash("192.168.10.64", sizeof("192.168.10.64")));
	insert_data_into_hash(pHashTbl,hash("192.168.12.65", sizeof("192.168.10.65")));
	insert_data_into_hash(pHashTbl,hash("192.168.13.66", sizeof("192.168.10.66")));
	print_hash_data(pHashTbl);
	//delete_data_from_hash(pHashTbl,hash("192.168.0.64", sizeof("192.168.0.64")));
	//print_hash_data(pHashTbl);
	//insert_data_into_hash(pHashTbl,hash("192.168.0.64", sizeof("192.168.0.64")));
	//print_hash_data(pHashTbl);

#else
	/*insert_data_into_hash(pHashTbl,22);
	insert_data_into_hash(pHashTbl,123);
	insert_data_into_hash(pHashTbl,436);
	insert_data_into_hash(pHashTbl,55);
	insert_data_into_hash(pHashTbl,157);
	insert_data_into_hash(pHashTbl,235);
	insert_data_into_hash(pHashTbl,256);
	insert_data_into_hash(pHashTbl,525);
	insert_data_into_hash(pHashTbl,724);
	insert_data_into_hash(pHashTbl,278);
	insert_data_into_hash(pHashTbl,209);
	insert_data_into_hash(pHashTbl,67);
	insert_data_into_hash(pHashTbl,54);
	insert_data_into_hash(pHashTbl,546);
	insert_data_into_hash(pHashTbl,350);
	insert_data_into_hash(pHashTbl,101);
	insert_data_into_hash(pHashTbl,23);
	insert_data_into_hash(pHashTbl,221);
	insert_data_into_hash(pHashTbl,1232);
	insert_data_into_hash(pHashTbl,4363);
	insert_data_into_hash(pHashTbl,554);
	insert_data_into_hash(pHashTbl,1575);
	insert_data_into_hash(pHashTbl,2356);
	insert_data_into_hash(pHashTbl,2567);
	insert_data_into_hash(pHashTbl,5258);
	insert_data_into_hash(pHashTbl,7249);
	insert_data_into_hash(pHashTbl,2780);
	insert_data_into_hash(pHashTbl,2091);
	insert_data_into_hash(pHashTbl,672);
	insert_data_into_hash(pHashTbl,543);
	insert_data_into_hash(pHashTbl,5464);
	insert_data_into_hash(pHashTbl,3505);
	insert_data_into_hash(pHashTbl,1016);
	insert_data_into_hash(pHashTbl,237);*/
	insert_data_into_hash(pHashTbl,123);
	insert_data_into_hash(pHashTbl,4363);
	insert_data_into_hash(pHashTbl,243);
	print_hash_data(pHashTbl);

	delete_data_from_hash(pHashTbl,123);
	print_hash_data(pHashTbl);
	insert_data_into_hash(pHashTbl,123);
	print_hash_data(pHashTbl);

	delete_data_from_hash(pHashTbl,4363);
	print_hash_data(pHashTbl);
	insert_data_into_hash(pHashTbl,4363);
	print_hash_data(pHashTbl);

	delete_data_from_hash(pHashTbl,4362);
	print_hash_data(pHashTbl);
	insert_data_into_hash(pHashTbl,4362);
	print_hash_data(pHashTbl);

	printf("4362 idx = %d\n", find_idx_in_hash(pHashTbl, 4362));
	printf("4361 idx = %d\n", find_idx_in_hash(pHashTbl, 4361));

#endif
	return 0;
}

