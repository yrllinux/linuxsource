#include "stdlib.h"
#include "stdio.h"
#include <string.h>

typedef unsigned char uint8;
typedef unsigned long long  uint64;

int read_cert_file(char *fname, uint8 *cert_data, int *cert_len)
{
	FILE *fp;

	*cert_len = 0;
	fp = fopen(fname, "rb");
	if (fp == NULL)
	{
		printf("open cert file %s failed\n", fname);
		return -1;
	}

	int len = fread(cert_data, 1, 5000, fp);
	fclose(fp);
	if (len <= 0)
	{
		printf("read cert file %s failed\n", fname);
		return -2;
	}

	*cert_len = len;
	return 0;
}

#pragma pack(1)
typedef struct s_pubkey{
	int	BitLen;
	uint8	XCoordinate[512/8];
	uint8	YCoordinate[512/8];
}pubkey_t;

typedef struct s_signature{
	int	BitLen;
	uint8	r[512/8];
	uint8	s[512/8];
}signature_t;

typedef struct tag_certificate_t
{
	int version;
	uint8 serial_num[16];
	uint8 signature_algorithm[128];
	char issuer[128];
	uint64 begin_time;
	uint64 end_time;
	char subject[128];
	pubkey_t pub_key;
	signature_t signature;
} certificate_t;
#pragma pack()

#define VPRINT
int get_sm2_cert_info(uint8 *cert_data, int cert_len, certificate_t *pcertificate)
{
	if(cert_data == NULL || pcertificate == NULL)
		return -1;

	uint8 len = 0;
	uint8 *p = cert_data;
	int j = 0;

	printf("\n-----start-----\n");

	//����ͷ��
	p += 0x8;
	//version
	p++;
	len = *p;
	p++;
	pcertificate->version = *(p+2);
#ifdef VPRINT
	printf("version:%d\n", pcertificate->version);
#endif

	//���к�
	p += len;
	p++;
	len = *p;
	p++;
	memcpy(pcertificate->serial_num, p, len);
#ifdef VPRINT
	printf("serialNumber:\n");
	for(j = 0; j < len; j++) {
		printf("%02x ", p[j]);
		if((j+1)%16 == 0)
			printf("\n");
	}
	printf("\n");
#endif

	//signature_algorithm
	p += len;
	p++;
	len = *p;
	p++;
	memcpy(pcertificate->signature_algorithm, p, len);
#ifdef VPRINT
	printf("signature_algorithm:\n");
	for(j = 0; j < len; j++) {
		printf("%02x ", p[j]);
		if((j+1)%16 == 0)
			printf("\n");
	}
	printf("\n");
#endif

	//Issuer
	p += len;
	p++;
	len = *p;
	//printf("0x%02x\n", len);
	p++;

	//validity
	p += len;
	p++;
	len = *p;
	//printf("0x%02x\n", len);
	p++;
	p += len;
	//subject
	p++;
	len = *p;
	//printf("0x%02x\n", len);
	p++;
	p += len;
	//subjectPublicKey
	p += 3;
	len = *p;
	p++;
	p += len;
	p++;
	len = *p;
	p++;
	//ǰ���00 04�����ֽڱ�ʾsm2�㷨������key������
	pcertificate->pub_key.BitLen = len-2;
	int length = (pcertificate->pub_key.BitLen)/2;
	memcpy(pcertificate->pub_key.XCoordinate, p+2, length);
	memcpy(pcertificate->pub_key.YCoordinate, p+2+length, length);
#ifdef VPRINT
	printf("pubkey-BitLen:0x%02x\n", pcertificate->pub_key.BitLen);
	printf("pubkey.XCoordinate:\n");
	for(j = 0; j < length; j++) {
		printf("%02x ", pcertificate->pub_key.XCoordinate[j]);
		if((j+1)%16 == 0)
			printf("\n");
	}
	printf("\npubkey.YCoordinate:\n");
	for(j = 0; j < length; j++) {
		printf("%02x ", pcertificate->pub_key.YCoordinate[j]);
		if((j+1)%16 == 0)
			printf("\n");
	}
	printf("\n");
#endif

	//extensions
	p += len;
	p++;
	len = *p;
	//printf("%d\n", len);
	p++;

	//signature
	p += len;
	p++;
	len = *p;
	p++;
	//printf("%d\n", len);
	p += len;
	p++;
	pcertificate->signature.BitLen = *p;
	p++;
	length = (pcertificate->signature.BitLen-1)/2;
	memcpy(pcertificate->signature.r, p+1, length);
	memcpy(pcertificate->signature.s, p+1+length, length);
#ifdef VPRINT
	printf("signature-BitLen:0x%02x\n", pcertificate->signature.BitLen);
	printf("signature.r:\n");
	for(j = 0; j < length; j++) {
		printf("%02x ", pcertificate->signature.r[j]);
		if((j+1)%16 == 0)
			printf("\n");
	}
	printf("\nsignature.s:\n");
	for(j = 0; j < length; j++) {
		printf("%02x ", pcertificate->signature.s[j]);
		if((j+1)%16 == 0)
			printf("\n");
	}
	printf("\n");
#endif

	return 0;
}

int main(int argc,char **argv)
{
	if(argc > 1) {
		uint8 cert_data[5000];
		int cert_len;
		read_cert_file(argv[1], cert_data, &cert_len);

		printf("cert-data:\n");
		int j = 0;
		for(; j < cert_len; j++) {
			printf("%02x ", cert_data[j]);
			if((j+1)%16 == 0)
				printf("\n");
		}
		printf("\n\n");

		certificate_t certificate;
		get_sm2_cert_info(cert_data, cert_len, &certificate);
	}

	return 0;
}

