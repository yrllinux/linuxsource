clear all
clc
close all;
X = imread('1.jpg');
SCRIPT entropy(X)