#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include <dirent.h>
#include <assert.h>
#include "jpg2bmp.h"
#include "harris.h"

#define MAX_VALUE 256
#define MAX_PIC_COUNT 200	//Ҫ������ͼƬ�������Ŀ
#define PIC_OUT_NUM 30    	//�����ͼƬ��Ŀ
#define TOTAL_COUNT_MIN 200
#define TOTAL_COUNT_MAX 235
#define ENTROPY 7.91
#define ENTROPY1 7.93
#define TMP_FILE "test.bmp"

float ent(float p[], int num_symbols)
{
	assert(p != NULL);

	int i = 0;
	float entropy = 0.0;
	for(i=0; i< num_symbols; i++)
	{
	  if(p[i] > 0.0)
	     entropy -= p[i] * (float) log( (double) p[i]);
	}

	return entropy / (float)log((double) 2.0);/*��Ϣ�ر���ʽ*/;
}

float entropy(const char *filename)/*����Ϣ��*/
{
	assert(filename != NULL);

	FILE *ifp = fopen(filename,"rb");
	if(ifp ==NULL)
	{
	   printf("Image file  cannot be opened for input.\n");
	   return;
	}

	fseek(ifp, 0, SEEK_END); /* set file pointer at end of file */
	int size = ftell(ifp)+1; /* gets size of file */

	unsigned char* img_content = (unsigned char*)malloc(size * sizeof(unsigned char));
	if (img_content == NULL)
	{
		printf("Unable to allocate memory for file.\n");
		fclose(ifp);
		return;
	}

	fseek(ifp, 0, SEEK_SET); /* set file pointer to begining of file */
	if(fread(img_content, 1, size, ifp) <=0 )
	{
		printf("[%s:%d] fread error\n", __FUNCTION__, __LINE__);
	}

	int j=0;
	int freq[MAX_VALUE]={0};
	for(; j<MAX_VALUE; j++)
		freq[j] = 0;

	int i=0;
	for(; i<size; i++)
		freq[ img_content[i] ] ++;
	free(img_content);

	float prob[MAX_VALUE]={0};
	for(j=0; j<MAX_VALUE; j++)
		prob[j] = (float)freq[j] / (float)size;

	return ent(prob, MAX_VALUE);
}

unsigned char buf[10240] = {0};
void filter_file(char *path_in, char *path_out)
{
	assert(path_in != NULL && path_out != NULL);

	FILE *ifp;
	int count=0,nreads=0,k=0,u=0;
	int ree[MAX_PIC_COUNT]={0},summ[MAX_PIC_COUNT]={0};
	float entropy_value[MAX_PIC_COUNT]={0};
	char file_in[MAX_PIC_COUNT][100];
	char file_out[MAX_PIC_COUNT][100];

	DIR *dir=NULL;
	if ( !(dir = opendir(path_in)) )
	{
		printf("%s:%d\n", __FUNCTION__, __LINE__);
		return;
	}

	char *name = NULL;
	struct dirent *ptr=NULL;
	while((ptr=readdir(dir))!=NULL)
	{
		if(ptr->d_name[0] == '.')
        	continue;

		name = ptr->d_name;
		if(strstr(name, ".jpg") == NULL)
			continue;

		strcpy(file_in[k],path_in);
		strcat(file_in[k],name);

		strcpy(file_out[k],path_out);
		strcat(file_out[k],name);

		entropy_value[k] = entropy(file_in[k]);
		read_jpeg_file(file_in[k], TMP_FILE);
		marrs(TMP_FILE);

		ree[k]=re;
		summ[k]=sum;
		re = 0;
		sum = 0;

		printf("[%d]%s\tsub:%d\ttotal:%d\tentropy:%f\n",k,file_in[k],ree[k],summ[k],entropy_value[k]);

		if(k >= MAX_PIC_COUNT)
			break;

		k++;
	}
	close(dir);

	int re_max = 0;
	for(u=0;u<k;u++)
	{
		if ((summ[u] > TOTAL_COUNT_MIN && summ[u] < TOTAL_COUNT_MAX) &&
			(entropy_value[u] > ENTROPY && entropy_value[u] < ENTROPY1) && ree[u] == re_max)
		{
			memset(buf, 0, sizeof(buf));

			FILE *fds = fopen(file_in[u],"rb");
			FILE *fdd = fopen(file_out[u],"wb");

			while( (nreads = fread( buf, 1, 1024, fds )) > 0 )
			{
				fwrite( buf, 1, nreads, fdd );/*дͼƬ��ָ���ļ���*/
			}

			fclose( fds );
			fclose( fdd );

			if(count >= PIC_OUT_NUM)
				return;

			count++;
		}

		if(u == k-1 && count < PIC_OUT_NUM && re_max <= 3)
		{
			u = 0;
			re_max++;
		}
	}
}

int main(int argc, char **argv)
{
	char *path_in="./pic0/";/*�趨��ȡͼƬ��·��*/
	char *path_out="./pic1/";/*�趨���ͼƬ��·��*/
	filter_file(path_in, path_out);
	return 0;
}


