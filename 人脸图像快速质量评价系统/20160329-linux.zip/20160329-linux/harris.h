#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>

#define WIDTHBYTES(i) ((i+31)/32*4)
#define PI 3.1415926535

//����ģ�����㺯��
//im������ͼ��  tp��ģ�����
extern int sum, re;
void mbys(double *im,double *out,int imW,int imH,double *tp,int tpW,int tpH);
void OnImgConvertGray(unsigned char *imgBuffer,unsigned char *grayBuffer,int ImageHeight,int ImageWidth);
void OnImgHarris(unsigned char *grayBuffer,int m_gausswidth,double m_sigma,int m_size,int m_thresh,int imagewidth,int imageheight);
void marrs(const char *filename);

