#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <stdlib.h>
#include <jpeglib.h>
#include <assert.h>

//��value��8λд��array[offset],��8λд��array[offset+1]
#define put_2b(array,offset,value)  \
         (array[offset] = (char) ((value) & 0xff), \
          array[offset+1] = (char) (((value) >> 8) & 0xff))
#define put_4b(array,offset,value)  \
         (array[offset] = (char) ((value) & 0xff), \
          array[offset+1] = (char) (((value) >> 8) & 0xff), \
          array[offset+2] = (char) (((value) >> 16) & 0xff), \
          array[offset+3] = (char) (((value) >> 24) & 0xff))

struct colormap{  //��ɫ���ṹ
	unsigned char blue;
	unsigned char green;
	unsigned char red;
	unsigned char reserved;
};

//д�ļ�ͷ
void write_bmp_header(j_decompress_ptr cinfo, FILE *output_file);
//д��λͼ����
void write_pixel_data(j_decompress_ptr cinfo, unsigned char *output_buffer, FILE *output_file);
//�ο���libjpeg�����example.c
int read_jpeg_file(const char *input_filename, const char *output_filename);

