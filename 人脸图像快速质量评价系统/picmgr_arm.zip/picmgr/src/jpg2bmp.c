#include "jpg2bmp.h"

//д�ļ�ͷ
void write_bmp_header(j_decompress_ptr cinfo, FILE *output_file)
{
	assert(output_file != NULL);

	int bits_per_pixel=0, cmap_entries=0;
	/* compute colormap size and total file size */
	if (cinfo->out_color_space == JCS_RGB)
	{
	     if (cinfo->quantize_colors)
		 {
	         /* colormapped rgb */
	         bits_per_pixel = 8;
	         cmap_entries = 256;
	     }
		 else
		 {
	         /* unquantized, full color rgb */
	         bits_per_pixel = 24;
	         cmap_entries = 0;
	     }
	}
	else
	{
	     /* grayscale output.  we need to fake a 256-entry colormap. */
	     bits_per_pixel = 8;
	     cmap_entries = 256;
	}

	int step = cinfo->output_width * cinfo->output_components;
	while ((step & 3) != 0)
		step++;

	/* file size */
	long headersize = 14 + 40 + cmap_entries * 4; /* header and colormap */
	long bfsize = headersize + (long)step * (long)cinfo->output_height;

	/* set unused fields of header to 0 */
	char bmpfileheader[14] = {0};
	char bmpinfoheader[40] = {0};
	memset(bmpfileheader, 0, sizeof(bmpfileheader));
	memset(bmpinfoheader, 0 ,sizeof(bmpinfoheader));

	/* fill the file header */
	bmpfileheader[0] = 0x42;/* first 2 bytes are ascii 'b', 'm' */
	bmpfileheader[1] = 0x4d;

	put_4b(bmpfileheader, 2, bfsize); /* bfsize */
	/* we leave bfreserved1 & bfreserved2 = 0 */
	put_4b(bmpfileheader, 10, headersize); /* bfoffbits */

	/* fill the info header (microsoft calls this a bitmapinfoheader) */
	put_2b(bmpinfoheader, 0, 40);   /* bisize */
	put_4b(bmpinfoheader, 4, cinfo->output_width); /* biwidth */
	put_4b(bmpinfoheader, 8, cinfo->output_height); /* biheight */
	put_2b(bmpinfoheader, 12, 1);   /* biplanes - must be 1 */
	put_2b(bmpinfoheader, 14, bits_per_pixel); /* bibitcount */

	/* we leave bicompression = 0, for none */
	/* we leave bisizeimage = 0; this is correct for uncompressed data */
	if (cinfo->density_unit == 2)
	{ /* if have density in dots/cm, then */
	     put_4b(bmpinfoheader, 24, (int)(cinfo->X_density*100)); /* xpels/m */
	     put_4b(bmpinfoheader, 28, (int)(cinfo->Y_density*100)); /* xpels/m */
	}

	put_2b(bmpinfoheader, 32, cmap_entries); /* biclrused */
	/* we leave biclrimportant = 0 */

	//д���ļ�ͷ
	if (fwrite(bmpfileheader, 1, 14, output_file) != (size_t)14)
	{
	     printf("write bmpfileheader error\n");
	}

	//д����Ϣͷ
	if (fwrite(bmpinfoheader, 1, 40, output_file) != (size_t)40)
	{
	     printf("write bmpinfoheader error\n");
	}

	//д����ɫ��,�Ҷ�ͼ
	if (cmap_entries ==256)
	{
		struct colormap rgb[256];
		memset(rgb, 0, sizeof(rgb));

		int i=0;
		for(;i<256;i++)
	    {
	        rgb[i].blue=i;
	        rgb[i].green=i;
	        rgb[i].red=i;
	        rgb[i].reserved=0;
	    }

		//д����ɫ��
		if (fwrite(rgb, 1, sizeof(struct colormap)*256, output_file) <0)
		{
		     printf("write color error\n");
		}
	}
}

//д��λͼ����
void write_pixel_data(j_decompress_ptr cinfo, unsigned char *output_buffer, FILE *output_file)
{
	assert(output_buffer != NULL && output_file != NULL);

	int row_width = cinfo->output_width * cinfo->output_components;
	int step = row_width;
	while ((step & 3) != 0)
		step++;

	unsigned char *pdata = (unsigned char *)malloc(step);
	memset(pdata, 0, step);

	//ÿ��д��һ�У����ҵ���rgb˳��windowsλͼ�洢˳����bgr����libjpeg����rgb
	unsigned char *tmp = output_buffer + row_width * (cinfo->output_height - 1);

	int rows=0, cols=0;
	if(cinfo->output_components==3)
	{
		//24bit���ͼ
		for (rows = 0; rows < cinfo->output_height; rows++)
		{
		     for (cols = 0; cols < row_width; cols += 3)
			 {
		             pdata[cols + 2] = tmp[cols + 0];
		             pdata[cols + 1] = tmp[cols + 1];
		             pdata[cols + 0] = tmp[cols + 2];
		     }
		     tmp -= row_width;
		     fwrite(pdata, 1, step, output_file);
		}
	}
	else //cinfo->output_components==1��8bit�Ҷ�ͼ
	{
		for (rows = 0; rows < cinfo->output_height; rows++)
		{
		     for (cols = 0; cols < row_width; cols ++)
			 {
		             pdata[cols] = tmp[cols];
		     }
		     tmp -= row_width;
		     fwrite(pdata, 1, step, output_file);
		}
	}

	free(pdata);
}

//�ο���libjpeg�����example.c
int read_jpeg_file(const char *input_filename, const char *output_filename)
{
	assert(input_filename != NULL && output_filename != NULL);

	struct jpeg_error_mgr jerr;
	struct jpeg_decompress_struct cinfo;
	cinfo.err = jpeg_std_error(&jerr);

	FILE *input_file = NULL;
	if ((input_file = fopen(input_filename, "rb")) == NULL)
	{
		fprintf(stderr, "can't open %s\n", input_filename);
		return -1;
	}

	FILE *output_file = NULL;
	if ((output_file = fopen(output_filename, "wb")) == NULL)
	{
		fprintf(stderr, "can't open %s\n", output_filename);
		return -1;
	}

	jpeg_CreateDecompress(&cinfo, JPEG_LIB_VERSION, \
	  (size_t)sizeof(struct jpeg_decompress_struct));

	/* specify data source for decompression */
	jpeg_stdio_src(&cinfo, input_file);

	/* read file header, set default decompression parameters */
	(void)jpeg_read_header(&cinfo, TRUE);

	/* start decompressor */
	(void)jpeg_start_decompress(&cinfo);

	int row_width = cinfo.output_width * cinfo.output_components;
	unsigned char *buffer = (unsigned char *)(*cinfo.mem->alloc_sarray)
	     ((j_common_ptr) &cinfo, JPOOL_IMAGE, row_width, 1);

	//дbmp�ļ�ͷ
	write_bmp_header(&cinfo, output_file);

	//����bmp������
	unsigned char *output_buffer = (unsigned char *)malloc(row_width * cinfo.output_height);
	memset(output_buffer, 0, row_width * cinfo.output_height);

	unsigned char *tmp = output_buffer;

	/* process data */
	while (cinfo.output_scanline < cinfo.output_height)
	{
		(void)jpeg_read_scanlines(&cinfo, (JSAMPARRAY)buffer, 1);
		memcpy(tmp, buffer, row_width);
		tmp += row_width;
	}

	//дbmp����
	write_pixel_data(&cinfo, output_buffer, output_file);

	free(output_buffer);

	(void)jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);

	/* close files, if we opened them */
	fclose(input_file);
	fclose(output_file);
	return 0;
}

